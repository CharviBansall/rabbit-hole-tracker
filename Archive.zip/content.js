(function () {
  let lastUrl = location.href;

  function trackVisit() {
    chrome.storage.local.get(["depth"], (result) => {
      let current = result.depth || 0;
      current += 1;
      chrome.storage.local.set({ depth: current });
    });

    const title = document.title;
    chrome.storage.local.get(["titles"], (result) => {
      const titles = result.titles || [];
      if (!titles.includes(title)) {
        titles.push(title);
        chrome.storage.local.set({ titles });
      }
    });
  }

  function checkUrlChange() {
    const currentUrl = location.href;
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      trackVisit();
    }
  }

  const observer = new MutationObserver(checkUrlChange);
  observer.observe(document.body, { childList: true, subtree: true });
  setInterval(checkUrlChange, 1000);

  trackVisit();

 
})();
