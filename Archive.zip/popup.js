function formatTime(s) {
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${m}m ${sec}s`;
}

function updateTimeDisplay() {
  chrome.runtime.sendMessage("getTime", (t) => {
    document.getElementById("time").textContent = formatTime(t || 0);
  });
}

document.getElementById("start").addEventListener("click", () => {
  chrome.runtime.sendMessage("start");
});

document.getElementById("stop").addEventListener("click", () => {
  chrome.runtime.sendMessage("stop");
});

document.getElementById("reset").addEventListener("click", () => {
  chrome.runtime.sendMessage("reset", () => {
    document.getElementById("depth").textContent = 0;
    document.getElementById("time").textContent = "0m 0s";
    const trail = document.getElementById("trail");
    if (trail) trail.innerHTML = ""; // Clear the trail list
  });
});



setInterval(updateTimeDisplay, 1000);
updateTimeDisplay();

chrome.storage.local.get(["depth", "titles"], (data) => {
  document.getElementById("depth").textContent = data.depth || 0;
  const trail = document.getElementById("trail");
  trail.innerHTML = "";
  (data.titles || []).forEach((title) => {
    const li = document.createElement("li");
    li.textContent = title;
    trail.appendChild(li);
  });
});
