let intervalId = null;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg === "start") {
    if (!intervalId) {
      intervalId = setInterval(() => {
        chrome.storage.local.get(["time"], (data) => {
          const current = data.time || 0;
          chrome.storage.local.set({ time: current + 1 });
        });
      }, 1000);
    }
  }

  if (msg === "stop") {
    if (intervalId) {
      clearInterval(intervalId);
      intervalId = null;
    }
  }

  if (msg === "reset") {
    if (intervalId) {
      clearInterval(intervalId);
      intervalId = null;
    }
    chrome.storage.local.set({ time: 0, depth: 0, titles: [] });
  }

  if (msg === "getTime") {
    chrome.storage.local.get(["time"], (data) => {
      sendResponse(data.time || 0);
    });
    return true;
  }
});
